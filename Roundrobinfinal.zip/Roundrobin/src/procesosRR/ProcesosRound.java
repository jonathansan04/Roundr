
package procesosRR;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class ProcesosRound extends JFrame implements Runnable ,ActionListener{

    JScrollPane scrollPane = new JScrollPane();
    JScrollPane scrollPane1 = new JScrollPane();
    
    JScrollPane scrollPane2 = new JScrollPane();
    JScrollPane scrollPane3 = new JScrollPane();
    
    JScrollPane scrollPane4 = new JScrollPane();
    JScrollPane scrollPane5 = new JScrollPane();
    
    JLabel label = new JLabel("Rafaga");
    JLabel label1 = new JLabel("Quantum = 4");
    JLabel label2 = new JLabel("Nombre del proceso: ");
    JLabel label3 = new JLabel("Proceso en ejecucion: Ninguno");
    JLabel label4 = new JLabel("Tiempo: ");
    JLabel label5 = new JLabel("Tabla de procesos ");
    JLabel label6 = new JLabel("Diagrama de Gant:");
    JLabel label7 = new JLabel("Tabla de Bloqueados:");
    JLabel label8 = new JLabel("Rafaga restante del proceso: 0");
   
    
    JButton botonIngresarRoundRobin = new JButton("Ingresar proceso");
    JButton botonIniciar = new JButton("Iniciar ejecucion ");
    JButton botonBloquear = new JButton("Bloquear proceso");
    
    JTextField tfNombre = new JTextField("A1");
    JTextField tfrafaga= new JTextField("");
    
    JTextField[][] tabla = new JTextField[100][7];
   
   
    JTextField[][] tablaBloqueados = new JTextField[100][3];
    JLabel[][] diagrama = new JLabel[50][200];  
    
    ListaCircular colaRoundRobin = new ListaCircular();
    
    Nodo nodoEjecutado;
    
    int filasRoundRobin = 0,  rafagaTemporal;
    int tiempoGlobal = 0;
    int coorX = 0;
    
    Thread procesos;
    
    public static void main(String[] args) {

        ProcesosRound pm = new ProcesosRound(); 
        pm.setBounds(0, 0, 1050, 650);
        pm.setTitle("Round Robin");
        pm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        pm.setVisible(true);
        
    }

    ProcesosRound(){
        
        Container c = getContentPane();
        c.setLayout(null);
        this.getContentPane().setBackground(Color.BLUE);
        
        c.add(label);
        c.add(label1);
        c.add(label2);
        c.add(label3);
        c.add(label4);
        c.add(label5);
        c.add(label6);
        c.add(label7);
        c.add(label8);
       
        c.add(scrollPane1);
        c.add(scrollPane3);
        c.add(scrollPane5);
     
        c.add(botonIngresarRoundRobin);
   
        c.add(botonIniciar);
        c.add(botonBloquear);
        
        c.add(tfNombre);
        c.add(tfrafaga);
     
        label.setBounds(700, 370, 300, 20);
        label1.setBounds(700, 320, 300, 20);
        label2.setBounds(700, 340, 300, 20);
        label3.setBounds(700, 285, 300, 20);
        label4.setBounds(700, 270, 300, 20);
        label5.setBounds(50, 330, 500, 20);
        label6.setBounds(50, 0, 300, 20);
        label7.setBounds(700, 0, 300, 20);
        label8.setBounds(700, 300, 300, 20);
     
        
        scrollPane.setBounds(50, 350, 2500, 2500);
        scrollPane.setPreferredSize(new Dimension(2500, 2500));  
        scrollPane.setBackground(Color.WHITE);
        
        scrollPane1.setBounds(50, 350, 600, 200);
        scrollPane1.setPreferredSize(new Dimension(1150, 400)); 
        scrollPane1.setBackground(Color.BLUE);
        
        scrollPane2.setBounds(50, 20, 2500, 2500);
        scrollPane2.setPreferredSize(new Dimension(2500, 2500));  
        scrollPane2.setBackground(Color.white);
        
        scrollPane3.setBounds(50, 20, 600, 300);
        scrollPane3.setPreferredSize(new Dimension(1150, 400)); 
        scrollPane3.setBackground(Color.BLUE);
        
        scrollPane4.setBounds(700, 20, 280, 1000);
        scrollPane4.setPreferredSize(new Dimension(500, 1000));  
        scrollPane4.setBackground(Color.WHITE);
        
        scrollPane5.setBounds(700, 20, 280, 250);
        scrollPane5.setPreferredSize(new Dimension(350, 350)); 
        scrollPane5.setBackground(Color.BLUE);
          
        tfNombre.setBounds(850, 340, 70, 20);
        tfrafaga.setBounds(850, 370, 70, 20);
        
        botonIngresarRoundRobin.addActionListener(this);
        botonIngresarRoundRobin.setBounds(700, 400, 200, 40);
        botonIngresarRoundRobin.setBackground(Color.LIGHT_GRAY);
                
      
        botonIniciar.addActionListener(this);
        botonIniciar.setBounds(700, 460, 200, 40);
        botonIniciar.setBackground(Color.LIGHT_GRAY);
        
        botonBloquear.addActionListener(this);
        botonBloquear.setBounds(700, 520, 200, 40);
        botonBloquear.setBackground(Color.LIGHT_GRAY);
        
  
        
    }
    
 
    public void dibujarTablaRoundRobin(String nombre, int rafaga, int tiempo){
        
        scrollPane.removeAll();
        
        JLabel texto1 = new JLabel("Proceso");
        JLabel texto2 = new JLabel("T. llegada");
        JLabel texto3 = new JLabel("Rafaga");
        JLabel texto4 = new JLabel("T. comienzo");
        JLabel texto5 = new JLabel("T. final");
        JLabel texto6 = new JLabel("T. retorno");
        JLabel texto7 = new JLabel("T. espera");
        
        texto1.setBounds(20, 20, 150, 20);
        texto2.setBounds(100, 20, 150, 20);
        texto3.setBounds(180, 20, 150, 20);
        texto4.setBounds(260, 20, 150, 20);
        texto5.setBounds(340, 20, 150, 20);
        texto6.setBounds(420, 20, 150, 20);
        texto7.setBounds(500, 20, 150, 20);
        
        scrollPane.add(texto1);
        scrollPane.add(texto2);
        scrollPane.add(texto3);
        scrollPane.add(texto4);
        scrollPane.add(texto5);
        scrollPane.add(texto6);
        scrollPane.add(texto7);
        
        for(int i = 0; i<filasRoundRobin; i++){
            
            for(int j = 0; j<7; j++){
            
                if(tabla[i][j] != null){
                    
                    scrollPane.add(tabla[i][j]);
                    
                } else {
                
                    tabla[i][j] = new JTextField();
                    tabla[i][j].setBounds(20 + (j*80), 40 + (i*25), 70, 20);
                    
                    scrollPane.add(tabla[i][j]);
                    
                }

            }
        
        }
        
        tabla[filasRoundRobin-1][0].setText(nombre);
        tabla[filasRoundRobin-1][1].setText(Integer.toString(tiempo));
        tabla[filasRoundRobin-1][2].setText(Integer.toString(rafaga));

        scrollPane.repaint();
        scrollPane1.setViewportView(scrollPane);
        
    }
    
   
    
    
    
    public void llenarBloqueados( ListaCircular cola, JScrollPane scrollPar, JScrollPane scrollImpar){
        
        scrollPane4.removeAll();
        
        JLabel texto1 = new JLabel("Proceso");
        JLabel texto2 = new JLabel("T. llegada");
        JLabel texto3 = new JLabel("Rafaga");
        
        texto1.setBounds(20, 20, 150, 20);
        texto2.setBounds(100, 20, 150, 20);
        texto3.setBounds(180, 20, 150, 20);
        
        scrollPane4.add(texto1);
        scrollPane4.add(texto2);
        scrollPane4.add(texto3);
        
        if(cola.getCabeza() != null){
        
        Nodo temp = cola.getCabeza().getSiguiente();
        
            for(int i = 0; i<cola.getTamaño()-1; i++){

                for(int j = 0; j<3 ; j++){

                        tablaBloqueados[i][j] = new JTextField("");
                        tablaBloqueados[i][j].setBounds(20 + (j*80), 40 + (i*25), 70, 20);

                        scrollPar.add(tablaBloqueados[i][j]);

                }

                tablaBloqueados[i][0].setText(temp.getLlave());
                tablaBloqueados[i][1].setText(tablaBloqueados[i][1].getText() + "," + Integer.toString(temp.getLlegada()));
                tablaBloqueados[i][2].setText(Integer.toString(temp.getRafaga()));
                
                temp = temp.getSiguiente();

            }
        
        }
        
        scrollPar.repaint();
        scrollImpar.setViewportView(scrollPar);
        
    }
    
    public void llenarRestante(){
        
        tabla[nodoEjecutado.getIndice()-1][3].setText(tabla[nodoEjecutado.getIndice()-1][3].getText() + "," + Integer.toString(nodoEjecutado.getComienzo()));
        tabla[nodoEjecutado.getIndice()-1][4].setText(tabla[nodoEjecutado.getIndice()-1][4].getText() + "," +Integer.toString(nodoEjecutado.getFinalizacion()));
        tabla[nodoEjecutado.getIndice()-1][5].setText(Integer.toString(nodoEjecutado.getFinalizacion() - nodoEjecutado.getLlegada()));
        
        String [] comienzos = tabla[nodoEjecutado.getIndice()-1][3].getText().split(","); 
        String [] finales = tabla[nodoEjecutado.getIndice()-1][4].getText().split(","); 
        finales[0] = "0";
        String cadena = "";
        
        for(int i = 1; i<comienzos.length; i++){
            
            cadena = cadena + (Integer.parseInt(comienzos[i]) - Integer.parseInt(finales[i-1])) + ",";
            
        }
          
        tabla[nodoEjecutado.getIndice()-1][6].setText(cadena);
        
        
    }
    
    public void dibujarDiagrama(String nombre, int coorX, int coorY){
        
        scrollPane2.removeAll();
        
        for(int i = 0; i<200; i++){
            
            diagrama[0][i] = new JLabel(Integer.toString(i));
            diagrama[0][i].setBounds(40 + (i*20), 20, 20, 20);

            scrollPane2.add(diagrama[0][i]);
            
        }
        
        diagrama[nodoEjecutado.getIndice()][0] = new JLabel("  " + nombre);
        diagrama[nodoEjecutado.getIndice()][0].setBounds(0, 20 + (nodoEjecutado.getIndice()*20), 50, 20);
        
        scrollPane2.add(diagrama[nodoEjecutado.getIndice()][0]);
        
        
        
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("barra.png"));

        Image imgEscalada = imgIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        Icon iconoEscalado = new ImageIcon(imgEscalada);
        
        for(int i = 1; i < filasRoundRobin + 1; i++){
            
            for(int j = 0; j < coorX+1; j++){
                
                if(diagrama[i][j] != null){
                
                    scrollPane2.add(diagrama[i][j]);
                    
                }
                
            }
            
        }
        
        diagrama[nodoEjecutado.getIndice()][coorX+1] = new JLabel();
        diagrama[nodoEjecutado.getIndice()][coorX+1].setBounds(40 + (coorX*20), 20 + (nodoEjecutado.getIndice()*20), 20, 20);
        diagrama[nodoEjecutado.getIndice()][coorX+1].setIcon(iconoEscalado);
        
        scrollPane2.add(diagrama[nodoEjecutado.getIndice()][coorX+1]);
        
        scrollPane2.repaint();
        scrollPane3.setViewportView(scrollPane2);
            
    }
    
    public void ingresar(ListaCircular cola, String nombre , int rafaga, int tiempo, int filas){
        
        cola.insertar(nombre, rafaga, tiempo, filas);
        
    }
    
  
    
    public int calcularRafaga(){
        
        return 1 + ((int) (Math.random()*12));
        
    }
    
  
 
    
    @Override
    public void actionPerformed(ActionEvent e) {
    
        if(e.getSource() == botonIngresarRoundRobin){
            
            filasRoundRobin++;
            
            String nombre = tfNombre.getText();
            String valorraf = tfrafaga.getText();
            int varafa=Integer.parseInt(valorraf);
            rafagaTemporal = varafa;
           // rafagaTemporal = calcularRafaga();
            
            ingresar(colaRoundRobin, nombre, rafagaTemporal, tiempoGlobal, filasRoundRobin);
            dibujarTablaRoundRobin(nombre, rafagaTemporal, tiempoGlobal);
            
            tfNombre.setText("A" + (filasRoundRobin + 1));
            
        
            
        }  else if(e.getSource() == botonIniciar){
        
            procesos = new Thread( this );
            procesos.start();  
            
        } else if(e.getSource() == botonBloquear){
        
            if(nodoEjecutado.getRafaga() != 0){
            
                filasRoundRobin++;
                ingresar(colaRoundRobin, nodoEjecutado.getLlave() + "*", nodoEjecutado.getRafaga(), tiempoGlobal, filasRoundRobin);
                dibujarTablaRoundRobin(nodoEjecutado.getLlave() + "*", nodoEjecutado.getRafaga(), tiempoGlobal);
                nodoEjecutado.setFinalizacion(tiempoGlobal);
                llenarRestante();
                colaRoundRobin.eliminar(colaRoundRobin.getCabeza());
                llenarBloqueados(colaRoundRobin, scrollPane4, scrollPane5);
                nodoEjecutado = colaRoundRobin.getCabeza();
                nodoEjecutado.setComienzo(tiempoGlobal);

            }
        }
        
    }
    
    @Override
    public void run() {
    
            try{

            while(colaRoundRobin.getTamaño() != 0){
                
               
                nodoEjecutado = colaRoundRobin.getCabeza();
                nodoEjecutado.setComienzo(tiempoGlobal);
                
                int tiempoEjecutado = 0;
                
                while(nodoEjecutado.getRafaga() > 0 && tiempoEjecutado < 4){
                    
                    nodoEjecutado.setRafaga(nodoEjecutado.getRafaga()-1);
                    
                    label3.setText("Proceso en ejecucion: " + nodoEjecutado.getLlave());
                    label4.setText("Tiempo: " + String.valueOf(tiempoGlobal) + " Segundos.");
                    label8.setText("Rafaga restante del proceso: " + nodoEjecutado.getRafaga());
                    
                    dibujarDiagrama(nodoEjecutado.getLlave(), coorX, nodoEjecutado.getIndice());
                    llenarBloqueados(colaRoundRobin, scrollPane4, scrollPane5);
                    
                    tiempoGlobal++;
                    coorX++;
                    tiempoEjecutado++;
                    
              
                
                    
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ProcesosRound.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }
                
                nodoEjecutado.setFinalizacion(tiempoGlobal);
                llenarRestante();
                
                if(nodoEjecutado.getRafaga() == 0){
                
                    colaRoundRobin.eliminar(colaRoundRobin.getCabeza());
                    
                } else if (tiempoEjecutado == 4){
                
                    colaRoundRobin.getCabeza().setLlave(colaRoundRobin.getCabeza().getLlave());
                    colaRoundRobin.intercambiar(colaRoundRobin.getCabeza());
                    
                }
                
            }

         
            label3.setText("Proceso en ejecucion: Ninguno");
            
        }catch(Exception e){
        
            System.out.print("Error");
            
        }  
    
    }
    
}
